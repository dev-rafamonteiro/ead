package com.ead.course.enums;

public enum CourseStatus {
    INPROGRESS,
    CONCLUDED;
}
