package com.ead.course.enums;

public enum UserType {
    ADMIN,
    STUDENT,
    INSTRUCTOR;
}
