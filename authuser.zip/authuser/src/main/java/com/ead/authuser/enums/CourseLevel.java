package com.ead.authuser.enums;

public enum CourseLevel {
    BEGINNER,
    INTERMEDIARY,
    ADVANCED;
}
